var num = 2.6

console.log(Math.random())
console.log(Math.floor(num))
console.log(Math.ceil(num))