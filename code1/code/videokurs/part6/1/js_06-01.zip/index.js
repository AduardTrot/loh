// number, string, boolean, null, undefined
// object

var car = {
  name: 'Ford',
  year: 2015,
  person: {

  }
}

// car.__proto__ => Object.prototype
// [] => Array => Object

console.log(car)