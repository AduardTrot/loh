export const config = {
  key: '123456'
}