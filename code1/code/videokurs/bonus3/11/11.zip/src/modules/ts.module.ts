const field: string = 'Hello Typescrip!'

interface WFM {
  field: string
}

const wfm: WFM = { field }

console.log('[Typescript]: ', wfm)