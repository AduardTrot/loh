sayHelloTo('Игорь')

// var sayHelloTo = function (name) {
//   console.log('Привет, ' + name)
// }

function sayHelloTo(name) {
  console.log('Привет, ' + name)
}
