/* 
  Number
  String
  Boolean
  Object
  Null
  Undefined
*/

var num = 42
var string = 'Message'
var isTrue = false // false
var obj = {a: 1}
var nothing = null
var undef = undefined

console.log(typeof undef)