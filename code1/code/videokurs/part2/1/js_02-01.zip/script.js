var message = 'Hello world! 2';
var Message = '';
var helloMessage = 'Hello again';

var $ = 'Dollar';
var _ = 'Underscore';

var message2 = 'Hello world message 2';
var message3 = "Hello world message 3";

var сообщение = 'Сообщение!'


console.log(сообщение)