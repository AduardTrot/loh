console.log('5 % 2', 5 % 2)
console.log('8 % 3', 8 % 3)
console.log('15 % 5', 15 % 5)

var i = 1
// i = i + 1
i++
console.log('i', i)
// i = i + 3
i *= 3
console.log('i', i)
i /= 1.5
console.log('i', i)

console.log('i', ++i)
console.log('i', i--)