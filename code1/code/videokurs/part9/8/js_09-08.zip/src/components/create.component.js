import { Component } from '../core/component'

export class CreateComponent extends Component {
  constructor(id) {
    super(id)
  }
}
