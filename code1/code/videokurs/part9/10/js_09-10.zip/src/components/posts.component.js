import { Component } from '../core/component'

export class PostsComponent extends Component {
  constructor(id) {
    super(id)
  }
}
