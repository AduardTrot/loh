import { Component } from '../core/component'

export class FavoriteComponent extends Component {
  constructor(id) {
    super(id)
  }
}
