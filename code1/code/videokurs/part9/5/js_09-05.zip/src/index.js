import {HeaderComponent} from './components/header.component'

const header = new HeaderComponent('header')
console.log(header)